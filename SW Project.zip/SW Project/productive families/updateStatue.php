<!DOCTYPE html>
<html>
<?php include 'connect.php'; ?>
<?php 
$d = $_GET['iid'];
$statue = "rejected" ;
$q = "UPDATE orderr SET statue = '$statue' WHERE orderID = $d ";
$result=mysql_query($q);
if($result)
header("location:A&R.php");
?>
</html>