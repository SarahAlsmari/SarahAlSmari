<!DOCTYPE html>


<?php
session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'productive_family'; //DB Name here
//Connect to mysql server
$con = mysql_connect($DB_HOST, $DB_USER, $DB_PASSWORD);
if(!$con) {
die('Failed to connect to server: ' .
mysql_error());
}
//Select database
$db = mysql_select_db($DB_DATABASE);
if(!$db) {
die("Unable to select database");
}

if(!(isSet($_SESSION['USER'])||isSet($_SESSION['PASS']) )){
	
	header ("location: Signin.php");
	
	
}
?>
<html style="background-color:#f1f7fc;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index (1)</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aguafina+Script">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alef">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amita">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pacifico">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ubuntu">
    <link rel="stylesheet" href="assets/css/Animated-Pretty-Product-List-v12.css">
    <link rel="stylesheet" href="assets/css/Article-List.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Footer-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider1.css">
    <link rel="stylesheet" href="assets/css/MUSA_product-display.css">
    <link rel="stylesheet" href="assets/css/MUSA_product-display1.css">
    <link rel="stylesheet" href="assets/css/Navbar-Fixed-Side.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search.css">
    <link rel="stylesheet" href="assets/css/Pop-Out-Vertical-Nav-w-Footer--Social-Links--1.css">
    <link rel="stylesheet" href="assets/css/Pop-Out-Vertical-Nav-w-Footer--Social-Links--11.css">
    <link rel="stylesheet" href="assets/css/Pretty-Table.css">
    <link rel="stylesheet" href="assets/css/Pretty-Table1.css">
    <link rel="stylesheet" href="assets/css/product-list-s.css">
    <link rel="stylesheet" href="assets/css/Simple-Slider.css">
    <link rel="stylesheet" href="assets/css/Simple-Vertical-Navigation-Menu-v-10.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Team-Boxed.css">
    <link rel="stylesheet" href="assets/css/Team-Grid.css">
	<script src ="assets/js/search.js" type = "text/javascript"> </script>
</head>

<body style="margin-right:40px;margin-left:40px;">
    <div></div><img src="assets/img/logo ٧.١٨.٣١ م.png" style="width:138px;height:153px;margin:0px;margin-left:76px;">
    <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
        <div class="container"><a class="navbar-brand" href="#"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse"
                id="navcol-1">
                <ul class="nav navbar-nav">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="index.html">Home</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="Product.php">Product</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="Regester.php">Register</a></li>
                </ul>
                <form class="form-inline mr-auto" action="search.php" method="get" >
                    <div class="form-group" ><label for="search-field"><i class="fa fa-search"></i></label>
					<input class="form-control search-field" type="text" name="search" id="search-field" onkeypress="searchVaild(event)" placeholder="Search.." > 
					</div>
					 
                </form>
                <ul class="nav navbar-nav">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="cart.php"><i class="fa fa-shopping-cart" style="font-size:25px;color:rgb(0,0,0);"></i></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="#"><i class="fa fa-envelope" style="font-size:25px;color:rgb(0,0,0);"></i></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="logout.php"><i class="fa fa-user" style="font-size:25px;color:rgb(0,0,0);"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div style="background-color:rgb(255,255,255);">
	
	<?php

	
	$qry = "SELECT * FROM courier WHERE Email='".$_SESSION['USER']."'AND password='".$_SESSION['PASS']."' ;";
	$result=mysql_query($qry);

if($result === FALSE)  
    die(mysql_error()); // TODO: better error handling


if($result)
	
	$row = mysql_fetch_array($result);
	
		


?>
        <h1 style="margin-right:0px;margin-left:175px;font-size:37px;margin-top:60px;">Name<em style="margin-left:205px;font-size:30px;margin-top:-7px;margin-bottom:0px;margin-right:0px;"><?php  print $row['name'];?></em></h1>
       



	   <h1 style="margin-right:0px;margin-left:175px;font-size:37px;margin-top:60px;">email<em style="margin-left:239px;font-size:30px;margin-top:-7px;margin-bottom:0px;margin-right:0px;"><?php  print $row['Email'];?> </em></h1>
        <h1 style="margin-right:0px;margin-left:175px;font-size:37px;margin-top:60px;">password<em style="margin-left:184px;font-size:30px;margin-top:-7px;margin-bottom:0px;margin-right:0px;"><?php  print $row['password'];?> </em></h1>
        <h1 style="margin-right:0px;margin-left:175px;font-size:37px;margin-top:60px;">phone number<em style="margin-left:91px;font-size:30px;margin-top:-7px;margin-bottom:0px;margin-right:0px;"><?php  print $row['phone'];?> </em></h1>
        <h1 style="margin-right:0px;margin-left:175px;font-size:37px;margin-top:60px;">address<em style="margin-left:205px;font-size:30px;margin-top:-7px;margin-bottom:0px;margin-right:0px;"><?php  print $row['address'];?> </em></h1>
		<button class="btn btn-primary" type="button" style="margin-left:163px;margin-bottom:20px;margin-top:33px;padding:16px;padding-right:28px;padding-left:28px;padding-bottom:13px;padding-top:13px;font-size:20px;background-color:rgb(108,174,224);">edit profile</button></div>
    <div
        class="footer-basic">
        <footer>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="index.html">Home</a></li>
                <li class="list-inline-item"><a href="Product.php">Product</a></li>
                <li class="list-inline-item"><a href="Regester.php">Register</a></li>
                <li class="list-inline-item"></li>
                <li class="list-inline-item"><a href="#"></a></li>
            </ul>
            <p class="copyright">&nbsp;323 SOFTWARE ENGINEERING 2 COURSE PROJECT GROUP#1</p>
            <p class="copyright">Design and coding by SGRK</p>
        </footer>
        </div>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/Animated-Pretty-Product-List-v12.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
        <script src="assets/js/MUSA_product-display.js"></script>
        <script src="assets/js/Pop-Out-Vertical-Nav-w-Footer--Social-Links--1.js"></script>
        <script src="assets/js/Simple-Slider1.js"></script>
</body>

</html>