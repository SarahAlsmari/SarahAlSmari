function searchVaild(e) {
  var searchBar = document.getElementById('search-field');
  searchBar.style.border = "none";
 
 
}