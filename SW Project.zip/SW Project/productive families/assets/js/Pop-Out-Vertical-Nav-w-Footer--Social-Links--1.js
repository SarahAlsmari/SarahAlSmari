function toggleNav() {
document.getElementById("sidebar").classList.toggle("active");
document.getElementById("nav-toggle").classList.toggle("active");
}
