        <?php include 'connect.php'; ?>

        <?php
          if(isset($_POST['btnreg'])){
                                $Name = addslashes($_POST['name']);
            $Email = addslashes($_POST['email']);
            $Pass = addslashes($_POST['pass']);
             $phone = addslashes($_POST['phone']);
            $address = addslashes($_POST['address']);

          
              $query =" insert into courier (name,password,address,phone,Email) VALUES ( '" .$Name. "' , '" .$Pass. "' , '" .$address. "' , '" .$phone. "' , '" .$Email. "')";
              if(mysqli_query($con,$query))
              header("location: index.html");
              else
              header("location: RegesterCourior.php");
 
 
            }
    
          ?>