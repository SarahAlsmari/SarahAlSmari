<!DOCTYPE html>

<?php 


$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'productive_family'; //DB Name here
//Connect to mysql server
$con = mysql_connect($DB_HOST, $DB_USER, $DB_PASSWORD);
if(!$con) {
die('Failed to connect to server: ' .
mysql_error());
}
//Select database
$db = mysql_select_db($DB_DATABASE);
if(!$db) {
die("Unable to select database");
}?>
<html style="background-color:#f1f7fc;">


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index (1)</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aguafina+Script">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alef">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amita">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pacifico">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ubuntu">
    <link rel="stylesheet" href="assets/css/Animated-Pretty-Product-List-v12.css">
    <link rel="stylesheet" href="assets/css/Article-List.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Footer-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider1.css">
    <link rel="stylesheet" href="assets/css/MUSA_product-display.css">
    <link rel="stylesheet" href="assets/css/MUSA_product-display1.css">
    <link rel="stylesheet" href="assets/css/Navbar-Fixed-Side.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search.css">
    <link rel="stylesheet" href="assets/css/Pop-Out-Vertical-Nav-w-Footer--Social-Links--1.css">
    <link rel="stylesheet" href="assets/css/Pop-Out-Vertical-Nav-w-Footer--Social-Links--11.css">
    <link rel="stylesheet" href="assets/css/Pretty-Table.css">
    <link rel="stylesheet" href="assets/css/Pretty-Table1.css">
    <link rel="stylesheet" href="assets/css/product-list-s.css">
    <link rel="stylesheet" href="assets/css/Simple-Slider.css">
    <link rel="stylesheet" href="assets/css/Simple-Vertical-Navigation-Menu-v-10.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Team-Boxed.css">
    <link rel="stylesheet" href="assets/css/Team-Grid.css">
	<script src ="assets/js/search.js" type = "text/javascript"> </script>
</head>

<body style="margin-right:40px;margin-left:40px;">
    <div></div><img src="assets/img/logo ٧.١٨.٣١ م.png" style="width:138px;height:153px;margin:0px;margin-left:76px;">
    <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
        <div class="container"><a class="navbar-brand" href="#"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse"
                id="navcol-1">
                <ul class="nav navbar-nav">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="index.html">Home</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="Product.php">Product</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="selectP&C.html">Register</a></li>
                </ul>
                <form class="form-inline mr-auto" action="search.php" method="get" >
                    <div class="form-group" ><label for="search-field"><i class="fa fa-search"></i></label>
					<input class="form-control search-field" type="text" name="search" id="search-field" onkeypress="searchVaild(event)" placeholder="Search.." > 
					</div>
					 
                </form>
                <ul class="nav navbar-nav">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="cart.php"><i class="fa fa-shopping-cart" style="font-size:25px;color:rgb(0,0,0);"></i></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="#"><i class="fa fa-envelope" style="font-size:25px;color:rgb(0,0,0);"></i></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="Signin.php"><i class="fa fa-user" style="font-size:25px;color:rgb(0,0,0);"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div style="margin-left:0px;width:230px;">
        <nav class="navbar navbar-light navbar-expand-md navigation-clean-button" style="margin-left:0px;">
            <div class="container"><a class="navbar-brand" href="#"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse"
                    id="navcol-1" style="width:187px;">
                    <ul class="nav navbar-nav mr-auto">
					
					
						
                        <li class="nav-item" role="presentation"><?php print '<a  class="nav-link" href="product_category.php?category=Tradishnal Food"  style="width:159px;" >Tradishnal Food</a> ';?></li>
						<li class="nav-item" role="presentation"><?php print '<a  class="nav-link" href="product_category.php?category=Cakes" style="width:154px;" >Cakes</a> ';?></li>
                        <li class="nav-item" role="presentation"><?php print '<a  class="nav-link"  href="product_category.php?category=Sandwich" style="width:166px;" >Pies &amp; Sandwich</a> ';?></li>
						<li class="nav-item" role="presentation"><?php print '<a  class="nav-link" href="product_category.php?category=Sweet" >Sweet</a> ';?></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <div class="container" style="width:900px;margin-top:-167px;margin-left:250px;background-color:rgb(241,247,252);">
        <div class="row product-list dev">
            
		 
		 
		 <?php
		 $qry="SELECT * FROM product";
    $result=mysql_query($qry); 
    //Check whether the query was successful or not 
    if($result){
        
    while($info = mysql_fetch_array( $result )){?>
   
			<div class="col-sm-6 col-md-4 product-item animation-element slide-top-left">
			   <div class="product-container" style="margin-top:5px;">
                    <div class="row">
                        <div class="col-md-12"><a href="#" class="product-image"><?php  echo '<img src="data:image/jpeg;base64,'.base64_encode($info['pic']).'"/>' ?></a></div>
                    </div>
                    <div class="row">
                        <div class="col-8">
                            <h2><a href="#"><?php print "".$info['Name']. ""; ?></a></h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-6"><?php print '<h5><a style="background-color:rgb(108,189,230);" name="selected" href="cart.php?p_id='.$info['Product_ID'].'" style="width:140px;">Select</h5>';?></div>
                                <div class="col-6">
                                    <p class="product-price"><?php  Print "<b>Price:&nbsp</b>".$info['Price'];?> SR  </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			</div>
	<?php }}?>
           
        </div>
    </div>
    <div class="footer-basic">
        <footer>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="index.html">Home</a></li>
                <li class="list-inline-item"><a href="Product.php">Product</a></li>
                <li class="list-inline-item"><a href="selectP&C.html">Register</a></li>
                <li class="list-inline-item"></li>
                <li class="list-inline-item"><a href="#"></a></li>
            </ul>
            <p class="copyright">&nbsp;323 SOFTWARE ENGINEERING 2 COURSE PROJECT GROUP#1</p>
            <p class="copyright">Design and coding by SGRK</p>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Animated-Pretty-Product-List-v12.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
    <script src="assets/js/MUSA_product-display.js"></script>
    <script src="assets/js/Pop-Out-Vertical-Nav-w-Footer--Social-Links--1.js"></script>
    <script src="assets/js/Simple-Slider1.js"></script>
</body>

</html>