

<?php 

session_start();

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'productive_family'; //DB Name here
//Connect to mysql server
$con = mysql_connect($DB_HOST, $DB_USER, $DB_PASSWORD);
if(!$con) {
die('Failed to connect to server: ' .
mysql_error());
}
//Select database
$db = mysql_select_db($DB_DATABASE);
if(!$db) {
die("Unable to select database");
}



if(!isset($_POST['type'])){
	header("location:Signin.php");
exit();}

$courier ='courier';
$productive='productive familie';



 if ($_POST['type']== 'courier');{
	
$qry = "SELECT * FROM courier WHERE Email='".$_POST['email']."'AND password='".$_POST['password']."' ;";

$result=mysql_query($qry);

if($result === FALSE)  
    die(mysql_error()); // TODO: better error handling


if($result){
	
	$row = mysql_fetch_array($result);

		
		if($row)
		
		{
			$_SESSION['USER'] = $row['Email'];
			$_SESSION['PASS'] = $row['password'];
			header("location:coruriIndex.php");
				exit();
			
		}

}

}


if ($_POST['type']== 'productiveFamilie');{

	 
$qry = "SELECT * FROM productive_family WHERE Email='".$_POST['email']."'AND password='".$_POST['password']."' ;";

$result=mysql_query($qry);

if($result === FALSE)  
    die(mysql_error()); // TODO: better error handling


if($result){
	
	$row = mysql_fetch_array($result);

		
		if($row)
		
		{
			$_SESSION['USER'] = $row['Email'];
			$_SESSION['PASS'] = $row['password'];
			header("location:indexPF.php");
				exit();
		}
		else
header("location: Signin.php");

}

}



?>