<?php

session_start();


unset($_SESSION['USER']);
unset($_SESSION['PASS']);

header("location: Signin.php");


?>