<?php include 'connect.php'; ?>
<?php
          if(isset($_POST['btnreg'])){
                                $Name = addslashes($_POST['name']);
            $Email = addslashes($_POST['email']);
            $Pass = addslashes($_POST['pass']);
 
          
              $query =" insert into productive_family (F_ID,Name,Email,password) VALUES ('' , '" .$Name. "' , '" .$Email. "' , '" .$Pass. "' )";
              if(mysqli_query($con,$query))
              header("location: index.html");
              else
              header("location: RegesterFamily.php");
 
            }
    
          ?>