
<?php 
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_DATABASE = 'productive_family'; //DB Name here
//Connect to mysql server
$con = mysql_connect($DB_HOST, $DB_USER, $DB_PASSWORD);
if(!$con) {
die('Failed to connect to server: ' .
mysql_error());
}
//Select database
$db = mysql_select_db($DB_DATABASE);
if(!$db) {
die("Unable to select database");
} ?>


           
<?php


		 	$qry = "DELETE FROM product WHERE Product_ID='".$_GET['selected']."' ;";

$result=mysql_query($qry);

	if($result === FALSE) { 
    die(mysql_error()); // TODO: better error handling
}
	if($result === TRUE) { 
	print '<script>alert("The product was deleted");</script>';}

header("location:indexPF.php");


?>
 