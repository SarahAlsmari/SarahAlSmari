<!DOCTYPE html>
<html>
<?php include 'connect.php'; ?>
<?php 
$d = $_GET['id'];
$statue = "accepted" ;
$q = "UPDATE orderr SET statue = '$statue' WHERE orderID = $d ";
$result=mysql_query($q);
if($result)
header("location:ListOfCourer.php");
?>
</html>