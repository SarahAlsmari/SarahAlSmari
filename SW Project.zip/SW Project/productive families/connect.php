<?php

$DB_HOST = 'localhost';
$DB_DATABASE = 'productive_family';
$DB_USER = 'root';
$DB_PASSWORD = '';
 
session_start();
 
if(!$con = mysqli_connect($DB_HOST, $DB_USER, $DB_PASSWORD)) {
  die('Failed to connect to server'.mysql_error());
}
 
if(!$db = mysqli_select_db($con,$DB_DATABASE)) {
  die('Unable to select database'.mysql_error());
} ?>