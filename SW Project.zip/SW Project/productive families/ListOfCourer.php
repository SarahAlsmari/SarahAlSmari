<?php
if(!(isSet($_SESSION['USER'])||isSet($_SESSION['PASS']) )){
	
	header ("location: Signin.php");
}
?>
<!DOCTYPE html>
<html style="background-color:#f1f7fc;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index (1)</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/material-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aguafina+Script">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alef">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amita">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pacifico">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ubuntu">
    <link rel="stylesheet" href="assets/css/Animated-Pretty-Product-List-v12.css">
    <link rel="stylesheet" href="assets/css/Article-List.css">
    <link rel="stylesheet" href="assets/css/Features-Boxed.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Footer-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider1.css">
    <link rel="stylesheet" href="assets/css/MUSA_product-display.css">
    <link rel="stylesheet" href="assets/css/MUSA_product-display1.css">
    <link rel="stylesheet" href="assets/css/Navbar-Fixed-Side.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Search.css">
    <link rel="stylesheet" href="assets/css/Pop-Out-Vertical-Nav-w-Footer--Social-Links--1.css">
    <link rel="stylesheet" href="assets/css/Pop-Out-Vertical-Nav-w-Footer--Social-Links--11.css">
    <link rel="stylesheet" href="assets/css/Pretty-Table.css">
    <link rel="stylesheet" href="assets/css/Pretty-Table1.css">
    <link rel="stylesheet" href="assets/css/product-list-s.css">
    <link rel="stylesheet" href="assets/css/Simple-Slider.css">
    <link rel="stylesheet" href="assets/css/Simple-Vertical-Navigation-Menu-v-10.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Team-Boxed.css">
    <link rel="stylesheet" href="assets/css/Team-Grid.css">
	<script src ="assets/js/search.js" type = "text/javascript"> </script>
</head>

<body style="margin-right:40px;margin-left:40px;">
    <div></div><img src="assets/img/logo ٧.١٨.٣١ م.png" style="width:138px;height:153px;margin:0px;margin-left:76px;">
    <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
        <div class="container"><a class="navbar-brand" href="#"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse"
                id="navcol-1">
                <ul class="nav navbar-nav">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="index.html">Home</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="Product.php">Product</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="selectP&C.html">Register</a></li>
                </ul>
                <form class="form-inline mr-auto" action="search.php" method="get" >
                    <div class="form-group" ><label for="search-field"><i class="fa fa-search"></i></label>
					<input class="form-control search-field" type="text" name="search" id="search-field" onkeypress="searchVaild(event)" placeholder="Search.." > 
					</div>
					 
                </form>
                <ul class="nav navbar-nav">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="cart.html"><i class="fa fa-shopping-cart" style="font-size:25px;color:rgb(0,0,0);"></i></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="#"><i class="fa fa-envelope" style="font-size:25px;color:rgb(0,0,0);"></i></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="logout.html"><i class="fa fa-user" style="font-size:25px;color:rgb(0,0,0);"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div style="margin-left:0px;">
        <nav class="navbar navbar-light navbar-expand-md navigation-clean-button" style="margin-left:0px;">
            <div class="container"><a class="navbar-brand" href="#"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse"
                    id="navcol-1">
                    <ul class="nav navbar-nav mr-auto">
                         <?php print '<li class="nav-item" role="presentation"><a class="nav-link" href="ADD.php?p_id='.$_GET['p_id'].'" style="width:140px;">Add Product</a></li>';?>
				<?php print '<li class="nav-item" role="presentation"><a class="nav-link" href="SelectProduct.php?p_id='.$_GET['p_id'].'" style="width:140px;">Edit Product</a></li>';?>
				<?php print '<li class="nav-item" role="presentation"><a class="nav-link" href="Delete.php?p_id='.$_GET['p_id'].'" style="width:140px;">Delete Product</a></li>';?>
				<?php print '<li class="nav-item" role="presentation"><a class="nav-link" href="A&R.php?p_id='.$_GET['p_id'].'" style="width:140px;">Received Order</a></li>';?>
				
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <div style="margin-top:-159px;background-color:#ffffff;width:1007px;"><strong style="font-size:25px;font-family:Alef, sans-serif;margin-left:284px;">Courier List :</strong>
       <!--- <div class="container" style="margin-left:270px;width:890px;">
            <div class="row" style="width:835px;">
                <div class="col-md-12" style="margin-top:25px;width:730px;"><small style="font-size:25px;font-family:Actor, sans-serif;">Courier Information&nbsp;</small><small style="font-size:25px;font-family:Actor, sans-serif;margin-left:60px;">Mobile Number</small></div>
            </div>
        </div>--->
               <div class="container" style="margin-left:300px;width:890px;">

        	 <?php
$db_host = 'localhost'; // Nama Server
$db_user = 'root'; // User Server
$db_pass = ''; // Password Server
$db_name = 'productive_family'; // Nama Database
 
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die ('Fail to connect to MySQL: ' . mysqli_connect_error());   
}
            $sql = 'SELECT * FROM courier';
         
$query = mysqli_query($conn, $sql);
 
   if (!$query) {
    die ('SQL Error: ' . mysqli_error($conn));
} 
 echo '<table class="table">
        <thead>
            <tr>
                <h1><th>Name</th></h1>
                <h1><th>Phone</th></h1>
                <h1><th>Address</th></h1>
            </tr>
        </thead>
        <tbody>';
            
/*$qry ='SELECT * FROM courier';
$result=mysql_query($qry);
            if($result) { 
while( $info = mysql_fetch_array($result))*/
            
            
 while ($row = mysqli_fetch_array($query)){

echo '<tr>
            <td>'.$row['name'].'</td>
            <td>'.$row['phone'].'</td>
         <td>'.$row['address'].'</td>
        </tr>';
} 
echo '
    </tbody>
</table>';
            
            mysqli_free_result($query);
mysqli_close($conn);

?>
            </div>

    </div>
    <div class="footer-basic">
        <footer>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="index.html">Home</a></li>
                <li class="list-inline-item"><a href="Product.php">Product</a></li>
                <li class="list-inline-item"><a href="selectP&C.html">Register</a></li>
                <li class="list-inline-item"></li>
                <li class="list-inline-item"><a href="#"></a></li>
            </ul>
            <p class="copyright">&nbsp;323 SOFTWARE ENGINEERING 2 COURSE PROJECT GROUP#1</p>
            <p class="copyright">Design and coding by SGRK</p>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Animated-Pretty-Product-List-v12.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
    <script src="assets/js/MUSA_product-display.js"></script>
    <script src="assets/js/Pop-Out-Vertical-Nav-w-Footer--Social-Links--1.js"></script>
    <script src="assets/js/Simple-Slider1.js"></script>
</body>

</html>