

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;


public class Server {
    
        // define Array List to save streams from clients 
        ArrayList clientStreams = new ArrayList();
        // define Array List to save current clients names 
        ArrayList<String> user = new ArrayList();
        // define PrintWriter to save chat 
        PrintWriter write = null; 
        // to save message history 
        String history; 
        // chat number to send the number to all conversation participators
        int chatnum = 0; 
        /**
     * @param args the command line arguments
     */
        
        public static void main(String[] args) {
            new Server().Conicton();}
    
        public void Conicton() {
		
		try {
                        // Create a Socket for a server and put port number more than 1024 
                        ServerSocket serverSock = new ServerSocket(4323);
                        // message when server wait client to connect 
                        System.out.println("wait for clients");
			while (true) {
                                // Create Socet for Clients and wait for clients to connect to server
				Socket clientSock = serverSock.accept();
                                // Create Print Writer to get OutputStream from client
				PrintWriter writer = new PrintWriter(clientSock.getOutputStream());
                                // Add to clientOutputStreams ArrayList
				clientStreams.add(writer);
                                // Create Thread to allow multiple Clients to connect to server at the same time
				Thread listener = new Thread(new Server.Thread_Deals(clientSock, writer));
				listener.start();
                                // message when client connect to server successfully
				System.out.println("Connection Success");
			} 
		} // end try
		catch (Exception ex)
		{
			System.out.println(ex);
		} // end catch
	} 
    
        // this class for add current client , then publish for all clients that new client connected 
	public class Thread_Deals implements Runnable	{
		BufferedReader reader;
		Socket sock;
                PrintWriter writer;
                
        
        public Thread_Deals(Socket socket, PrintWriter w) {
		// Create new inputStreamReader and then add it to a BufferedReader
                        writer = w;
			try {
				sock = socket;
				InputStreamReader isReader = new InputStreamReader(sock.getInputStream());
				reader = new BufferedReader(isReader);
			} // end try
			catch (Exception ex) {
				System.out.println("error beginning StreamReader");
			} // end catch

		} // end Thread_Deals()
        

		public void run() {
                        
                        String message;// for save client message
			String[] data; // to save message 
                        //here we check for recieved messages from clients 
      			try {
				while ((message = reader.readLine()) != null) {

					System.out.println("Received: " + message);
					data = message.split("#");
                                        for (String token:data) {                            
                                            System.out.println(token);                                 
                                        } 
                                        // if data ended with the keyword "Connect" then server calls userAdd function
                                        if (data[2].equals("Connect")) {

                                                Propagation((data[0] + "#" + data[1] + "#" + "Chat"));
                                                add(data[0]);} 
                                        
                                        // if data ended with the keyword "Leave" then the server calls userRemove  function
                                        if (data[2].contains("Leave")) {
                                                Propagation((data[0] + "#Leave Conversation." + "#" + "Chat"));
                                                remove(data[0]);
					} 
                                        // if data contain the keyword "Chat" then the server calls pubish function
                                        if (data[2].contains("Chat")) {
                                            write = new PrintWriter(new BufferedWriter(new FileWriter(data[0] + ".txt", true)));
                                            write.println("==================================");
                                            write.close(); 
                                            chatnum+=1; 
                                            Propagation(data[0] + "#Request" + "#" + data[4] + "#" + chatnum);
                                                
					}
                                        // if data contain the keyword "Join" then the server calls pubish function
                                        if (data[2].contains("Join")) {
                                            write = new PrintWriter(new BufferedWriter(new FileWriter(data[0] + ".txt", true)));
                                            write.println("==================================");
                                            write.close();
                                            Propagation(data[0] + "#Join" + "#" + data[4] + "#" + data[5]);
					}
                                        // if data contain the keyword "Send" then the server calls pubish function
                                        if (data[2].contains("Send")) {
                                                Propagation(data[0] + "#Send" + "#" + data[4] + "#" + data[5] + "#" + data[6]);
                                                System.out.println(data[0] + "#Send" + "#" + data[4] + "#" + data[5] + "#" + data[6]);
                                                savemassege(data[0], data[4],data[5]);
					} 
                                        // if data contain the keyword "ReadMsg" then the server save messages in text file 
                                        if (message.contains("ReadMsg")) {
                                            System.out.println("Read History");
                                            history = "";
                                            BufferedReader readFile = new BufferedReader(new FileReader(data[0] + ".txt"));
                                            while(readFile.ready())
                                            {
                                                history += readFile.readLine() + "@@";
                                            }
                                            System.out.println(history);
                                            Propagation(data[0] + "##ReadMsg##" + history);
                                        }
                                        // if data contain the keyword "Finish" then the server calls pubish function
                                        if (data[2].contains("Finish")) {
                                                Propagation(data[0] + "#Finish" + "#" + data[4] + "#" + data[5] + "#" + data[6]);
       					}
                                       
			     } // end while
			} // end try
			catch (Exception ex) {
				System.out.println("Lost a connection");
                                clientStreams.remove(writer);
			} // end catch
		} // end run()
	} // end class Thread_Deals
        
        // this function for add new user 
        public void add (String us) {
                
            if(!user.contains(us))
            {
                user.add(us);
                String[] List = new String[(user.size())];
                user.toArray(List);           
                for (String sign:List) {                 
                    Propagation(sign + "# #Connect");
                }
            }
	}
        
        // this function for remove user 
	public void remove (String us) {
                user.remove(us);
	}
        
        // this function for publish for new user or that users is leave
        public void Propagation(String m) {
		Iterator it = clientStreams.iterator();
		while (it.hasNext()) {
			try {
				PrintWriter writer = (PrintWriter) it.next();
                                // send to other users message (if client connect or leave)
				writer.println(m);
				System.out.println("Sending" + m);
                                writer.flush();
			} // end try
			catch (Exception ex) {
				System.out.println(ex);
			} 
		} 
	}
        
        // this function for save messages between users
        public void savemassege(String FU, String SU, String M) throws IOException
        {
            String[] splits = SU.split("@@");
            for(int i=0; i<splits.length ; i++)
            {
                write = new PrintWriter(new BufferedWriter(new FileWriter(splits[i] + ".txt", true)));
                write.println(FU + ": " + M);
                write.close();
            }
        }
       
        
        
    
    
} // end
